DOCUMENTATION = 'module: ping\nshort_description: sample'
